import { configureStore } from "@reduxjs/toolkit";

import reducer from "./AllReducer";

const store = configureStore({
  reducer,
});

export default store;
