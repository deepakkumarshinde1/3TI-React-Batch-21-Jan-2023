import { useUserContext } from "./context/UserContext";

const App = () => {
  let { userList, lastInput, userInput, getUserValue } = useUserContext();
  return (
    <>
      <center>
        <input ref={userInput} type="text" placeholder="Enter Name" />
        <input ref={lastInput} type="text" placeholder="Enter Last Name" />
        <button onClick={getUserValue} className="btn btn-danger">
          Save
        </button>
        <hr />
        <ul className="list-group col-4">
          <li className="list-group-item">
            Users
            <span className="ms-2 badge bg-primary rounded-pill">
              {userList.length}
            </span>
          </li>
          {userList.map((user, index) => {
            return (
              <li key={index} className="list-group-item">
                {user.firstName} {user.lastName}
              </li>
            );
          })}
        </ul>
      </center>
    </>
  );
};

export default App;
