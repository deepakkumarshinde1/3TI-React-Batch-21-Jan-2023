import { createContext, useContext, useState } from "react";

// context create
let CounterContext = createContext({});

// set a provider
export const CounterContextProvider = (props) => {
  let { children } = props;
  let [counterList, setCounterList] = useState([10, 20, 30, 50]);
  // loop
  let incCount = (index) => {
    console.log("hello", index);
    counterList[index] += 1;
    setCounterList([...counterList]);
  };
  let resetCount = (index) => {
    counterList[index] = 0;
    setCounterList([...counterList]);
  };

  const values = {
    counterList,
    incCount,
    resetCount,
  };
  return (
    <>
      <CounterContext.Provider value={values}>
        {children}
      </CounterContext.Provider>
    </>
  );
};

// use that context ==> create our own hook
export let useCounterContext = () => {
  return useContext(CounterContext);
};
