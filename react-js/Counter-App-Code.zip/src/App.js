// import

import { useState } from "react";
import CounterFunction from "./components/CounterFunction";
import { useCounterContext } from "./context/CounterContext";

// code
function App() {
  let { counterList } = useCounterContext();
  return (
    <>
      <center>
        {counterList.map((value, index) => {
          return (
            <CounterFunction
              key={index}
              count={value}
              start={value}
              end={value + 10}
              index={index}
            />
          );
        })}
      </center>
    </>
  );
}

// export
export default App;

// props =>
// send data from parent component to child component
// we need to use "props"
// props i.e property
// parent ===> child (one data binding)
// props ==> is a {} (object)
// which can gain data from outer world
// props are read only in nature

// state
// handel data in component
// state => alpha, number, boolean , array,object ,fun call
// start are read & write
// https://youtu.be/EynAnD8nDfc
